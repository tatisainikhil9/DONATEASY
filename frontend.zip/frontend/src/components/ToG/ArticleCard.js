import React from 'react';
import { Row, Col, Divider } from 'antd';
import { Avatar } from 'antd';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableBody from '@mui/material/TableBody';
import Paper from '@mui/material/Paper';
import { styled } from '@mui/material/styles';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';


const ArticleCard = ({ detail }) => {
    const StyledTableCell = styled(TableCell)(({ theme }) => ({
        [`&.${tableCellClasses.head}`]: {
            backgroundColor: theme.palette.common.black,
            color: theme.palette.common.white,
        },
        [`&.${tableCellClasses.body}`]: {
            fontSize: 14,
        },
    }));

    const StyledTableRow = styled(TableRow)(({ theme }) => ({
        '&:nth-of-type(odd)': {
            backgroundColor: theme.palette.action.hover,
        },
        // hide last border
        '&:last-child td, &:last-child th': {
            border: 0,
        },
    }));

    return (
        <div class="row">
            <div class="col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Special title treatment</h5>
                        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                    </div>
                </div>
            </div>
        </div>
        // <Row className='rounded shadow-sm mx-md-0 mb-4 overflow-hidden bg-4' style={{ minHeight: 200 }}>
        //     {/* <Col className="gutter-row" xs={24} lg={8}>
        //         <div className='h-100'>
        //             <img src={detail.donatedProduct} alt="" className='w-100 article-card-img' />
        //         </div>
        //     </Col> */}
        //     <Col className="gutter-row" xs={24} lg={16}>
        //         <div className='h-100'>

        //             <div className='d-flex'>
        //                 <Avatar src={detail.donorImage} size={25} style={{ color: '#f56a00', backgroundColor: '#fde3cf' }} className='m-3 ms-md-4'>U</Avatar>
        //                 <div className='mt-3'>
        //                     <p className='m-0 p-0 article-card-donor-name'>{detail.id}</p>
        //                     <small className='m-0 p-0 article-card-donor-desc'>{detail.payment_method}</small>
        //                 </div>
        //             </div>

        //             <Divider className='m-0' />

        //             <div className='mx-3 mb-3 m-md-4'>
        //                 <p className='article-card-donor-desc'>{detail.amount}</p>
        //             </div>

        //         </div>
        //     </Col>
        // </Row>
    );
};

export default ArticleCard;