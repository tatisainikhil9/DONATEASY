import React, { useState, useEffect } from "react";
import Footer from '../SharedComponents/Footer/Footer';
import Navbar from '../SharedComponents/Navbar/Navbar';
import Newsletter from '../SharedComponents/Newsletter/Newsletter';
import ArticleCard from './ArticleCard';
import './ToG.scss';
import axios from 'axios';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableBody from '@mui/material/TableBody';
import Paper from '@mui/material/Paper';
import { styled } from '@mui/material/styles';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';

import { Row, Col } from 'antd';

const ToG = () => {

    const [data1, setData] = useState([])

    useEffect(() => {
        axios.get('http://localhost:5000/getAllTransactions')
            .then(res => {
                setData(res.data);
            })
    }, [])

    const StyledTableCell = styled(TableCell)(({ theme }) => ({
        [`&.${tableCellClasses.head}`]: {
            backgroundColor: theme.palette.common.black,
            color: theme.palette.common.white,
            fontSize: '1.2rem'
        },
        [`&.${tableCellClasses.body}`]: {
            fontSize: 16,
        },
    }));

    const StyledTableRow = styled(TableRow)(({ theme }) => ({
        '&:nth-of-type(odd)': {
            backgroundColor: theme.palette.action.hover,
        },
        // hide last border
        '&:last-child td, &:last-child th': {
            border: 0,
        },
    }));

    return (
        <section className='bg-5'>
            <Navbar />

            <header className='center tog-header mb-4'>
                <h2 className='m-0 p-0'>Recent Donations</h2>
            </header>

            <div style={{ padding: "1rem 8rem 1rem 8rem" }}>
                    <TableContainer component={Paper}>
                        <Table sx={{ minWidth: 700 }} aria-label="customized table">
                            <TableHead>
                                <TableRow>
                                    <StyledTableCell style={{ "text-align": "center" }}>Name of Donor</StyledTableCell>
                                    <StyledTableCell style={{ "text-align": "center" }}>Donated to</StyledTableCell>
                                    <StyledTableCell style={{ "text-align": "center" }}>Amount</StyledTableCell>
                                    <StyledTableCell style={{ "text-align": "center" }}>Date</StyledTableCell>
                                    <StyledTableCell style={{ "text-align": "center" }}>Mode of Payment</StyledTableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {
                                    data1 && data1.map(
                                        (dataItem) => {
                                            return (
                                            <StyledTableRow key={dataItem.id}>
                                                <StyledTableCell style={{ "text-align": "center" }}>{dataItem.username}</StyledTableCell>
                                                <StyledTableCell style={{ "text-align": "center" }}>{dataItem.ngoname}</StyledTableCell>
                                                <StyledTableCell style={{ "text-align": "center" }}>{dataItem.amount}</StyledTableCell>
                                                <StyledTableCell style={{ "text-align": "center" }}>{dataItem.time}</StyledTableCell>
                                                <StyledTableCell style={{ "text-align": "center" }}>{dataItem.payment_method}</StyledTableCell>
                                            </StyledTableRow>
                                            )
                                        }
                                    )
                                }
                            </TableBody>
                        </Table>
                    </TableContainer>
                </div>

            {/* <Row gutter={[{ xs: 8, sm: 16, md: 24 }, { xs: 8, sm: 16, md: 24 }]}
                className='mb-5 px-4'
                justify='center'>

                <Col className="gutter-row" xs={24} lg={12}>
                    <section className='article-section min-vh-100 article-card-container'>
                        {
                            data1.map(data => <ArticleCard detail={data}/>)
                        }
                    </section>
                </Col>
            </Row> */}

            {/* <Newsletter />
            <Footer /> */}

        </section>
    );
};

export default ToG;