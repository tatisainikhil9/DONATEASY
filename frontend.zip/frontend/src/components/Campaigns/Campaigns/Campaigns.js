import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableBody from '@mui/material/TableBody';
import Paper from '@mui/material/Paper';
import { styled } from '@mui/material/styles';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';


import ActiveCampaign from '../../Home/ActiveCampaign/ActiveCampaign';
import Footer from '../../SharedComponents/Footer/Footer';
import Navbar from '../../SharedComponents/Navbar/Navbar';
import Newsletter from '../../SharedComponents/Newsletter/Newsletter';


// import Button from '@mui/material/Button'
// import Typography from '@mui/material/Typography'
// import TableContainer from '@mui/material/TableContainer'
// import Table from '@mui/material/Table'
// import TableHead from '@mui/material/TableHead'
// import TableRow from '@mui/material/TableRow'
// import TableBody from '@mui/material/TableBody'
// import Paper from '@mui/material/Paper'
// import { styled } from '@mui/material/styles'
// import TableCell, { tableCellClasses } from '@mui/material/TableCell'


const Campaigns = () => {

    const [data1, setData] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:5000/getCampaigns')
            .then(res => {
                setData(res.data);
            })
    }, [])

    const StyledTableCell = styled(TableCell)(({ theme }) => ({
        [`&.${tableCellClasses.head}`]: {
            backgroundColor: theme.palette.common.black,
            color: theme.palette.common.white,
            fontSize: 23
        },
        [`&.${tableCellClasses.body}`]: {
            fontSize: 20,
        },
    }));

    const StyledTableRow = styled(TableRow)(({ theme }) => ({
        '&:nth-of-type(odd)': {
            backgroundColor: theme.palette.action.hover,
        },
        // hide last border
        '&:last-child td, &:last-child th': {
            border: 0,
        },
    }));

    return (
        <section id='campaigns' className='w-100'>

            <Navbar />

            <header className='center tog-header mb-4'>
                <h2 className='m-0 p-0'>List of NGOs</h2>
            </header>

            <div style={{ padding: "2rem" }}>
                <div>
                    <TableContainer component={Paper}>
                        <Table sx={{ minWidth: 700 }} aria-label="customized table">
                            <TableHead>
                                <TableRow>
                                    <StyledTableCell style={{ "text-align": "center" }}>Name</StyledTableCell>
                                    <StyledTableCell style={{ "text-align": "center" }}>Cause</StyledTableCell>
                                    <StyledTableCell ></StyledTableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {
                                    data1 && data1.map(
                                        (dataItem) => {
                                            return (
                                            <StyledTableRow key={dataItem.id}>
                                                <StyledTableCell style={{ "text-align": "center" }}>{dataItem.name}</StyledTableCell>
                                                <StyledTableCell style={{ "text-align": "center" }}>{dataItem.cause}</StyledTableCell>
                                                <StyledTableCell style={{ "text-align": "center" }}><Button variant="outlined" color="success">Donate</Button></StyledTableCell>
                                            </StyledTableRow>
                                            )
                                        }
                                    )
                                }
                            </TableBody>
                        </Table>
                    </TableContainer>
                </div>
                <br />
            </div>
        </section>
    );
};

export default Campaigns;