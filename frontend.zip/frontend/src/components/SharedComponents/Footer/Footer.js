import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css'

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFacebookF, faGoogle, faInstagram, faTwitter, faLinkedin } from '@fortawesome/free-brands-svg-icons'
import { faPaperPlane, faEnvelopeOpen } from '@fortawesome/free-regular-svg-icons'

const Footer = () => {
    return (
        <div className="container-fluid pb-0 mb-0 justify-content-center text-light body">
        </div >
    );
};

export default Footer;