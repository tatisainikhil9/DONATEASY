import React from 'react';
import './Newsletter.scss'

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEnvelopeOpen } from '@fortawesome/free-regular-svg-icons'

const Newsletter = () => {
    return (
        <div></div>

    );
};

export default Newsletter;