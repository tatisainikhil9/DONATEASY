const firebaseConfig = {
    apiKey: "AIzaSyCLGVEuD74EVuPv8ywrd02C2yBhWyt8dSc",
    authDomain: "give-01.firebaseapp.com",
    projectId: "give-01",
    storageBucket: "give-01.appspot.com",
    messagingSenderId: "351552896240",
    appId: "1:351552896240:web:59b662d145ff7149661635"
  };

  export default firebaseConfig;